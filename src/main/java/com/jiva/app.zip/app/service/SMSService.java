package com.jiva.app.service;

import java.util.Map;

public interface SMSService {

	String sendSmsWithGupSup(String uri);

}
