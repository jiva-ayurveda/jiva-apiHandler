package com.jiva.app.dtos;

public class BotPaymentLinkGeneratorDto {

}
