package com.jiva.app.dtos;

import java.io.Serializable;
import java.util.List;

public class IperformanceInboundDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String status;
	private List<String> data;
	
	
	
}
