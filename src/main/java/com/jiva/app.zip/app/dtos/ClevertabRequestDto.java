package com.jiva.app.dtos;

import java.io.Serializable;

public class ClevertabRequestDto implements Serializable{

	private String patientfname;
	private String patientlname;
	private String patientCity;
	private String gender;
	private String age;
	private String poCreateDate;
	private String appointmentDt;
	private String dhanId;
	private String poType;
	private String poSource;
	
	
	
	
	
	
}
