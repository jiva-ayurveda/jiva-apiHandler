package com.jiva.app.monitoring;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;

@Endpoint(id = "custom")
public class CustomActuatorEndpoint {

}
