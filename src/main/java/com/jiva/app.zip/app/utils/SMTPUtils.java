package com.jiva.app.utils;

public class SMTPUtils {

}
