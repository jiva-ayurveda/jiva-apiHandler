package com.jiva.app.comman.utils;

public interface JivaConstants {

	String NORMAL_TEMPLATE = "normal.ftlh";
	
}
